using UnityEngine;

[System.Serializable]
public struct Wave
{
    public GameObject[] waveObjects;
    public int spawnCount;
}
