public enum State
{
    Waiting = 0,
    Counting = 1,
    Spawning = 2
}
